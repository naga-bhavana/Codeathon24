import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class Codeathon {

	@Given("I want to open browser")
	def i_want_to_open_github_application_Browser() {
		WebUI.openBrowser('')
		WebUI.delay(6)
		WebUI.maximizeWindow()
		WebUI.navigateToUrl(GlobalVariable.url)
	}

	@When("user wants to enter the email address and password and click on login button")
	def i_want_enter_the_email_address() {
		WebUI.delay(4)
		WebUI.setText(findTestObject('Object Repository/loginpage/email'), 'prasannapasupuleti94@gmail.com')
		WebUI.setText(findTestObject('Object Repository/loginpage/emailpassword'), 'HKps12#@')
		WebUI.click(findTestObject('Object Repository/loginpage/login'))
	}

	@When("user wants to Verify that user is able to see weather page")
	def Verify_that_user_is_able_to_see_weather_page() {
		WebUI.delay(4)
		WebUI.verifyElementPresent(findTestObject('Object Repository/VerifyPage/Verification_OfPage'), 10)
	}

	@Then("user wants to click on sing up button and needs to enter name email and password and confirmpassword")
	def user_wants_to_enter_name_email_password_confirmpassword() {
		WebUI.delay(5)
		WebUI.click(findTestObject('Object Repository/loginpage/signup'))
		WebUI.setText(findTestObject('Object Repository/loginpage/name'), 'prasannapasupuleti')
		WebUI.delay(3)
		WebUI.setText(findTestObject('Object Repository/loginpage/signupemail'), 'prasannapasupuleti94@gmail.com')
		WebUI.delay(3)
		WebUI.setText(findTestObject('Object Repository/loginpage/signuppassword'), 'HKps12#@')
		WebUI.delay(3)
		WebUI.setText(findTestObject('Object Repository/loginpage/confirmpassword'), 'HKps12#@')
		WebUI.delay(3)
		WebUI.click(findTestObject('Object Repository/loginpage/submit'))
	}


	@Then("user wants to Click on search bar and enter any location")
	def user_wants_to_Click_on_search_bar_and_enter_any_location() {
		WebUI.delay(5)
		WebUI.setText(findTestObject('Object Repository/SearchText/Search'), 'Hyderabad, India')
		WebUI.delay(3)
		WebUI.click(findTestObject('Object Repository/SearchText/Search_Icon'))
	}

	@Then("user wants Verify that user is able to see weather report of the enterd location")
	def user_wants_to_Verify_that_user_is_able_to_see_weatherReport_of_the_enterd_location() {
		WebUI.delay(5)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Location/Location_Verification'), 10)
	}

	@Then("user wants to Go to settings and verify that user is able to change the language")
	def user_wants_to_Go_to_settings_and_verify_that_user_is_able_to_change_the_language() {
		WebUI.delay(5)
		WebUI.scrollToPosition(0, 500)
		WebUI.verifyTextPresent('English' , true)
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Language'), 1)
		WebUI.delay(5)
		WebUI.verifyTextPresent('Cymraeg' , true)
		
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Language'), 0)
		
	}
	
	@Then("user wants to Verify that user is able to switch temperature from Celcius to Fahrenheit")
	def user_wants_to_Verify_that_user_is_able_to_switch_temperature_from_Celcius_to_Fahrenheit() {
		WebUI.delay(5)
		WebUI.scrollToPosition(0, 500)
		WebUI.verifyTextPresent('Celsius' , true)
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Temp'), 1)
		WebUI.delay(5)
		WebUI.verifyTextPresent('Fahrenheit' , true)
		
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Temp'), 0)
		
	}
	
	@Then("Verify that user is able to switch wind speed from mile per hour to kilometer per hour")
	def Verify_that_user_is_able_to_switchWindSpeed_from_MilePerHou_to_kilometerPerHour() {
		WebUI.delay(5)
		WebUI.scrollToPosition(0, 700)
		WebUI.delay(5)
		//WebUI.verifyTextPresent('Miles Per hour' , true)
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Wind speed'), 1)
		WebUI.delay(5)
		//WebUI.verifyTextPresent('Kilometers per hour' , true)
		
		WebUI.delay(5)
		WebUI.selectOptionByIndex(findTestObject('Object Repository/Settings/Wind speed'), 0)
		
	}
	
	def check_text() {
		// Locate the elements using XPath
		WebElement element1 = driver.findElement(By.xpath("Object Repository/Settings/Temp_Cel"))
		WebElement element2 = driver.findElement(By.xpath("Object Repository/Settings/Temp_Fel"))
		
		// Get the text from the elements
		String text1 = element1.getText()
		String text2 = element2.getText()
		
		// Compare the text and take action based on the result
		if (text1.equals(text2)) {
			// The text elements are the same
			println("Text elements are the same.")
		}
		else {
			// The text elements are different
			println("Text elements are different.")
			// You can perform additional actions here if needed
		}
	}
}