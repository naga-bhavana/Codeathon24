<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Kukatpalle, Telangana</name>
   <tag></tag>
   <elementGuidId>d03a7abc-18a5-4ece-b274-7d9979a735bb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.header-loc</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='C'])[1]/preceding::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>70f50329-7d5b-4039-a9f2-71cbbbf454fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-loc</value>
      <webElementGuid>982aa226-c94c-47ce-a2f2-3a4086c2bd98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kukatpalle, Telangana</value>
      <webElementGuid>ff865237-ddc6-4220-a7d2-090b7df44d98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;accuweather&quot;]/body[@class=&quot;three-day full-animation rfphrase-disabled&quot;]/div[@class=&quot;template-root&quot;]/div[@class=&quot;basic-header&quot;]/div[@class=&quot;header-outer&quot;]/div[@class=&quot;header-inner&quot;]/a[@class=&quot;header-city-link&quot;]/h1[@class=&quot;header-loc&quot;]</value>
      <webElementGuid>4b53e65c-f88f-40d5-8570-c558f3ed92a9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='C'])[1]/preceding::h1[1]</value>
      <webElementGuid>a940e022-c28f-42eb-af3a-be777320fcf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/preceding::h1[1]</value>
      <webElementGuid>91fad75f-0037-46f1-b350-3e38c5aeb342</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kukatpalle, Telangana']/parent::*</value>
      <webElementGuid>dda20039-09e6-4890-b793-059485ce9b58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>4978b1d5-753e-47b9-b3d6-0ae8156328d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Kukatpalle, Telangana' or . = 'Kukatpalle, Telangana')]</value>
      <webElementGuid>33ddde81-c22d-4e1e-bbaa-f3ff1641038b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
