<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_LocationChevron downLocationNewsVideosU_ea07e3</name>
   <tag></tag>
   <elementGuidId>c222f7c0-faa1-48fb-926d-461c4984b6b0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.page-hero-content__left</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Podcasts'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b2055baf-8624-43b1-b385-2b08a2e90ce5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>page-hero-content__left</value>
      <webElementGuid>4fff05b2-46c9-4ec3-b503-5c6f5872ffaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			


	
		
		
			
		
		
		
			


	
		
			Location
		
		
	Chevron down
	


	
	

				Location
				
			

				News
				
			

				Videos
				
			
	


		
	
	
		
			
			Use your current location
		
		
	


			
				Recent Locations
					
						
								
	
		Gosha Mahal, India
		
	
	India
	
		
		
31° C
		
	
	
			RealFeel®
		32°
	


						
					
			
		</value>
      <webElementGuid>68db1a68-9958-43dc-968c-5bbfcd714242</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;accuweather&quot;]/body[@class=&quot;home full-animation rfphrase-disabled&quot;]/div[@class=&quot;template-root&quot;]/div[@class=&quot;page-hero hero-2 content-module&quot;]/div[@class=&quot;page-hero-content no-video&quot;]/div[@class=&quot;page-hero-content__left&quot;]</value>
      <webElementGuid>3ba4a442-fef8-4989-a76e-a3f0f894faca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Podcasts'])[1]/following::div[3]</value>
      <webElementGuid>4ef1a0a4-b958-4fe3-acdd-5c55a70497e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Video'])[1]/following::div[3]</value>
      <webElementGuid>229b60b1-021d-4a47-8a97-daf4d69e9155</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>a0d0d299-94aa-46f9-895a-1efd7d131e73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
			


	
		
		
			
		
		
		
			


	
		
			Location
		
		
	Chevron down
	


	
	

				Location
				
			

				News
				
			

				Videos
				
			
	


		
	
	
		
			
			Use your current location
		
		
	


			
				Recent Locations
					
						
								
	
		Gosha Mahal, India
		
	
	India
	
		
		
31° C
		
	
	
			RealFeel®
		32°
	


						
					
			
		' or . = '
			


	
		
		
			
		
		
		
			


	
		
			Location
		
		
	Chevron down
	


	
	

				Location
				
			

				News
				
			

				Videos
				
			
	


		
	
	
		
			
			Use your current location
		
		
	


			
				Recent Locations
					
						
								
	
		Gosha Mahal, India
		
	
	India
	
		
		
31° C
		
	
	
			RealFeel®
		32°
	


						
					
			
		')]</value>
      <webElementGuid>3dce5445-e7a5-42cb-9789-82f74ee80b7c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
