<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Chevron down</name>
   <tag></tag>
   <elementGuidId>ae40a5e3-160b-4ba0-9d09-00b116d5d1ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.icon-chevron.arrow</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>180fe6b5-88f2-49e9-ace3-23e0c978bab6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>icon-chevron  arrow</value>
      <webElementGuid>f99aea1f-a411-4ef5-bc81-16065fd38411</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xmlns</name>
      <type>Main</type>
      <value>http://www.w3.org/2000/svg</value>
      <webElementGuid>0d37d02a-a6dd-48da-86d3-00901511bb95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>10</value>
      <webElementGuid>63c5c06c-4e06-43fe-aa55-e7cf8b95d637</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>height</name>
      <type>Main</type>
      <value>6</value>
      <webElementGuid>822b863d-1009-4243-b5a6-19c7d43048a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 10 6</value>
      <webElementGuid>a5c7b70f-6daf-45ce-b104-68659222155b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>img</value>
      <webElementGuid>8eeaa0fb-d40e-4693-a722-27555d4c06ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-labelledby</name>
      <type>Main</type>
      <value>chevronSVG</value>
      <webElementGuid>dfd1cc93-31b4-46f6-95c0-87441fbbe5a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Chevron down
	
</value>
      <webElementGuid>b6581aef-7011-4c6e-8cc8-85d5341876ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;accuweather&quot;]/body[@class=&quot;home full-animation rfphrase-disabled&quot;]/div[@class=&quot;template-root&quot;]/div[@class=&quot;page-hero hero-2 content-module&quot;]/div[@class=&quot;page-hero-content no-video&quot;]/div[@class=&quot;page-hero-content__left&quot;]/div[@class=&quot;featured-search-bar featured-search&quot;]/div[@class=&quot;searchbar-content&quot;]/div[@class=&quot;search-options&quot;]/div[@class=&quot;dropdown-legacy left-bar&quot;]/div[@class=&quot;displayed-item&quot;]/svg[@class=&quot;icon-chevron  arrow&quot;]</value>
      <webElementGuid>ed2e1bc7-e8d6-4c6c-87f5-aeb5f110946a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>5e941439-9c8d-434e-97f8-43ff19e3e215</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Podcasts'])[1]/following::*[name()='svg'][4]</value>
      <webElementGuid>60d943d7-8746-47c1-81f4-07c798df68c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[2]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>4385ddff-e183-45fa-9a38-287cf62cf87a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News'])[2]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>6c21d4e7-cfe3-4a68-99f6-e333f4c7fbd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//svg[(text() = '
	Chevron down
	
' or . = '
	Chevron down
	
')]</value>
      <webElementGuid>e53c520e-bc9e-4daf-b2a5-673464b33d35</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
